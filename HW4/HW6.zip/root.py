import cherrypy
import sqlite3
import os
import html

def init_table(thread_index):
    cherrypy.thread_data.conn = sqlite3.connect("data.db")
    cur = cherrypy.thread_data.conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS data (
        name text,
        comment text
    )
    """)
    cherrypy.thread_data.conn.commit()
    cur.close()
cherrypy.engine.subscribe("start_thread", init_table)

class root(object):
    @cherrypy.expose
    def index(self):
        with open("index.html", "r") as file: return file.read()

    @cherrypy.expose
    def get_comments(self):
        cur = cherrypy.thread_data.conn.cursor()
        cur.execute("""
        SELECT * FROM data
        """)
        data_comments = cur.fetchall()
        cur.close()

        data_html = ""
        if len(data_comments) == 0:
            data_html = "There are no comments yet."
        for record in data_comments:
            name = html.escape(record[0])
            comment = html.escape(record[1])
            data_html += "<p>"+name+"'s comment: "+comment+"</p>"
        return data_html
    @cherrypy.expose
    def add_comment(self, name, comment):
        if len(name) == 0:
            return "You did not enter a name."
        if len(name) > 50:
            return "Your name is more than 50 characters.  Please enter a shorter name."
        if len(comment) == 0:
            return "You did not enter a comment."
        if len(comment) > 1000:
            return "Your comment is more than 1000 characters.  Please enter a shorter comment."
        cur = cherrypy.thread_data.conn.cursor()
        cur.execute("""
        INSERT INTO data VALUES (?,?)
        """, (name, comment))
        data_comments = cur.fetchall()
        cherrypy.thread_data.conn.commit()
        cur.close()
        return ""

if __name__ == "__main__":
    cherrypy.quickstart(root(), config={
                        "/static": {
                        "tools.staticdir.on": True,
                        "tools.staticdir.dir": os.path.abspath("./static")
                        }
    })
